package com.mycompany.poe1;

import java.util.ArrayList;
import java.util.List;

public class MessageManager {

private final ArrayList<Message> sentMessages =
new ArrayList<>();

private final ArrayList<Message> disregardedMessages =
new ArrayList<>();

private final ArrayList<Message> storedMessages =
new ArrayList<>();

private final ArrayList<String> messageHashes =
new ArrayList<>();

private final ArrayList<String> messageIDs =
new ArrayList<>();

// Add a message according to its status.
public void addMessage(Message msg, String status) {
switch (status.toLowerCase()) {
case "sent":
sentMessages.add(msg);
break;
case "disregarded":
disregardedMessages.add(msg);
break;
case "stored":
storedMessages.add(msg);
break;
default:
throw new IllegalArgumentException(
"Invalid message status");
}
// Record identifiers once the message is accepted.
String details = msg.printMessages();
for (String line : details.split("\\R")) {
if (line.startsWith("Message ID: ")) {
messageIDs.add(line.substring(12));
} else if (line.startsWith("Message Hash: ")) {
messageHashes.add(line.substring(14));
}
}
}

// Display details of sent messages.
public String displaySentMessages() {
if (sentMessages.isEmpty()) {
return "No messages have been sent.";
}
StringBuilder result = new StringBuilder();
for (Message msg : sentMessages) {
result.append(msg.printMessages())
.append("\n\n");
}
return result.toString().trim();
}

// Find the longest stored message.
public String longestStoredMessage() {
String longest = "";
for (Message msg : storedMessages) {
String text = getField(msg, "Message: ");
if (text.length() > longest.length()) {
longest = text;
}
}
return longest;
}

// Search stored messages by their ID.
public String searchByMessageID(String id) {
for (Message msg : storedMessages) {
if (getField(msg, "Message ID: ").equals(id)) {
return msg.printMessages();
}
}
return "Message not found.";
}

// Find stored messages for a specific recipient.
public String searchByRecipient(String recipient) {
StringBuilder result = new StringBuilder();
for (Message msg : storedMessages) {
if (getField(msg, "Recipient: ")
.equals(recipient)) {
result.append(getField(msg, "Message: "))
.append("\n");
}
}
return result.length() == 0
? "No messages found."
: result.toString().trim();
}

// Delete a stored message using its hash.
public String deleteByHash(String hash) {
for (int i = 0; i < storedMessages.size(); i++) {
Message msg = storedMessages.get(i);
if (getField(msg, "Message Hash: ")
.equals(hash)) {
String text = getField(msg, "Message: ");
storedMessages.remove(i);
messageHashes.remove(hash);
messageIDs.remove(
getField(msg, "Message ID: "));
return "Message: \"" + text
+ "\" successfully deleted.";
}
}
return "Message hash not found.";
}

// Display a report of all stored messages.
public String storedMessagesReport() {
if (storedMessages.isEmpty()) {
return "No stored messages.";
}
StringBuilder result = new StringBuilder();
for (Message msg : storedMessages) {
result.append(msg.printMessages())
.append("\n\n");
}
return result.toString().trim();
}

// Extract a named field from existing Message output.
private String getField(Message msg, String prefix) {
for (String line : msg.printMessages().split("\\R")) {
if (line.startsWith(prefix)) {
return line.substring(prefix.length());
}
}
return "";
}

public List<Message> getSentMessages() {
return new ArrayList<>(sentMessages);
}

public List<Message> getStoredMessages() {
return new ArrayList<>(storedMessages);
}

public List<Message> getDisregardedMessages() {
return new ArrayList<>(disregardedMessages);
}

public List<String> getMessageHashes() {
return new ArrayList<>(messageHashes);
}

public List<String> getMessageIDs() {
return new ArrayList<>(messageIDs);
}
}