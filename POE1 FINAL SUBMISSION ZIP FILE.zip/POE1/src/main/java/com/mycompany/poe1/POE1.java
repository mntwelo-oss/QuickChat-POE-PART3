

    package com.mycompany.poe1;

import java.util.Scanner;

public class POE1 {

public static void main(String[] args) {

Scanner input = new Scanner(System.in);

System.out.println("Welcome to QuickChat!");

System.out.print("Enter first name: ");
String firstName = input.nextLine();

System.out.print("Enter last name: ");
String lastName = input.nextLine();

System.out.print("Create username: ");
String username = input.nextLine();

System.out.print("Create password: ");
String password = input.nextLine();

System.out.print("Enter cellphone (+27): ");
String cellPhone = input.nextLine();

Login login = new Login(
firstName,
lastName,
username,
password,
cellPhone
);

String registration = login.registerUser();
System.out.println(registration);

if (!registration.equals(
"User registered successfully.")) {
return;
}

System.out.println("\nLOGIN");

System.out.print("Enter username: ");
String enteredUsername = input.nextLine();

System.out.print("Enter password: ");
String enteredPassword = input.nextLine();

boolean loggedIn = login.loginUser(
enteredUsername,
enteredPassword
);

System.out.println(
login.returnLoginStatus(loggedIn)
);
if (loggedIn) {

System.out.println("Welcome to QuickChat.");

System.out.print(
"How many messages would you like to enter? ");
int maxMessages = Integer.parseInt(input.nextLine());

int messagesEntered = 0;
java.util.ArrayList<Message> sentMessages =
new java.util.ArrayList<>();
MessageManager manager = new MessageManager();
boolean running = true;

while (running) {

System.out.println("\n1) Send Messages");
System.out.println("2) Show recently sent messages");
System.out.println("3) Quit");
System.out.println("4) Stored Messages");
System.out.print("Choose an option: ");

String option = input.nextLine().trim();

switch (option) {

case "1":
if (messagesEntered >= maxMessages) {
System.out.println(
"Message limit reached.");
break;
}

System.out.print("Recipient (+27...): ");
String recipient = input.nextLine();

System.out.print("Message: ");
String text = input.nextLine();

Message msg = new Message(recipient, text);

if (!msg.checkRecipientCell().equals(
"Cell phone number successfully captured.")) {
System.out.println(msg.checkRecipientCell());
break;
}

if (!msg.checkMessageLength().equals(
"Message ready to send.")) {
System.out.println(msg.checkMessageLength());
break;
}

System.out.println("\n1) Send Message");
System.out.println("2) Disregard Message");
System.out.println("3) Store Message to send later");
System.out.print("Choose an option: ");

String actionInput = input.nextLine();

try {
int action = Integer.parseInt(actionInput);

if (action == 1) {
System.out.println(msg.sentMessage(1));
System.out.println(msg.printMessages());
sentMessages.add(msg);
manager.addMessage(msg, "sent");
messagesEntered++;

} else if (action == 2) {
System.out.println("Message disregarded.");
manager.addMessage(msg, "disregarded");

} else if (action == 3) {
System.out.println(msg.storeMessage());
manager.addMessage(msg, "stored");
messagesEntered++;


} else {
System.out.println("Invalid action.");
}

} catch (java.io.IOException e) {
System.out.println(
"Unable to store message: "
+ e.getMessage());

} catch (NumberFormatException e) {
System.out.println(
"Please enter a valid option.");
}
break;

case "2":
if (sentMessages.isEmpty()) {
System.out.println(
"No messages have been sent.");
} else {
for (Message m : sentMessages) {
System.out.println(m.printMessages());
System.out.println();
}
}
break;

case "3":
System.out.println(
"Total messages sent: "
+ Message.returnTotalMessages());
System.out.println("Goodbye!");
running = false;
break;
case "4":
System.out.println("\nSTORED MESSAGES");
System.out.println("1) Display stored messages");
System.out.println("2) Display longest stored message");
System.out.println("3) Search by message ID");
System.out.println("4) Search by recipient");
System.out.println("5) Delete by message hash");
System.out.println("6) Display full report");

System.out.print("Choose an option: ");
String storedChoice = input.nextLine();

switch (storedChoice) {
case "1":
System.out.println(manager.storedMessagesReport());
break;

case "2":
System.out.println(manager.longestStoredMessage());
break;

case "3":
System.out.print("Enter message ID: ");
String id = input.nextLine();
System.out.println(manager.searchByMessageID(id));
break;

case "4":
System.out.print("Enter recipient: ");
String recipientSearch = input.nextLine();
System.out.println(
manager.searchByRecipient(recipientSearch));
break;

case "5":
System.out.print("Enter message hash: ");
String hash = input.nextLine();
System.out.println(manager.deleteByHash(hash));
break;

case "6":
System.out.println(manager.storedMessagesReport());
break;

default:
System.out.println("Invalid option.");
}
break;

default:
System.out.println("Invalid option.");
} // closes switch

} // closes while

} // closes if (loggedIn)

} // closes main method

} // closes POE1 class


