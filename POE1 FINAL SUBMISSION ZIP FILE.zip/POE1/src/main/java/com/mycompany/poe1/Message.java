package com.mycompany.poe1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;

public class Message {

private static final SecureRandom random =
new SecureRandom();

private static int totalMessagesSent = 0;

private String messageID;
private String recipient;
private String message;
private String messageHash;
private int messageNumber;

public Message(String recipient, String message) {

this.recipient = recipient;
this.message = message;
this.messageNumber = totalMessagesSent;

long number = random.nextLong(
10_000_000_000L);

this.messageID =
String.format("%010d", number);

this.messageHash = createMessageHash();
}

public boolean checkMessageID() {
return messageID.matches("\\d{10}");
}

public String checkRecipientCell() {

if (recipient.matches("\\+27[0-9]{9}")) {
return "Cell phone number successfully captured.";
}

return "Cell phone number is incorrectly formatted "
+ "or does not contain an international code. "
+ "Please correct the number and try again.";
}

public String checkMessageLength() {

if (message.length() <= 250) {
return "Message ready to send.";
}

int extra = message.length() - 250;

return "Message exceeds 250 characters by "
+ extra + "; please reduce the size.";
}

public String createMessageHash() {

String[] words = message.trim().split("\\s+");

String firstWord = words[0];
String lastWord = words[words.length - 1];

return (messageID.substring(0, 2)
+ ":" + messageNumber
+ ":" + firstWord + lastWord)
.toUpperCase();
}


public String sentMessage(int choice) {

switch (choice) {

case 1:
totalMessagesSent++;
return "Message successfully sent.";

case 2:
return "Press 0 to delete the message";

case 3:
return "Message successfully stored";

default:
return "Invalid option selected.";
}
}

public String printMessages() {

return "Message ID: " + messageID
+ "\nMessage Hash: " + messageHash
+ "\nRecipient: " + recipient
+ "\nMessage: " + message;
}

public static int returnTotalMessages() {

return totalMessagesSent;
}

public String storeMessage() throws IOException {

Path file = Path.of("stored-messages.json");

String json = "{"
+ "\"messageID\":\"" + escapeJson(messageID) + "\","
+ "\"messageHash\":\"" + escapeJson(messageHash) + "\","
+ "\"recipient\":\"" + escapeJson(recipient) + "\","
+ "\"message\":\"" + escapeJson(message) + "\""
+ "}";

String existing = Files.exists(file)
? Files.readString(file).trim()
: "";

String updated;

if (existing.isEmpty() || existing.equals("[]")) {

updated = "[\n" + json + "\n]";

} else if (existing.startsWith("[")
&& existing.endsWith("]")) {

updated = existing.substring(
0, existing.length() - 1)
+ ",\n" + json + "\n]";

} else {

throw new IOException(
"Invalid JSON file format.");
}

Files.writeString(file, updated);

return "Message successfully stored";
}

private static String escapeJson(String value) {

return value.replace("\\", "\\\\")
.replace("\"", "\\\"")
.replace("\n", "\\n")
.replace("\r", "\\r")
.replace("\t", "\\t");
   }
}
