package com.mycompany.poe1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

@Test
public void testUsernameCorrectlyFormatted() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "+27821234567");

assertTrue(login.checkUserName());
}

@Test
public void testUsernameIncorrectlyFormatted() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntwelo", "Test@123", "+27821234567");

assertFalse(login.checkUserName());
}

@Test
public void testPasswordMeetsComplexity() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "+27821234567");

assertTrue(login.checkPasswordComplexity());
}

@Test
public void testPasswordDoesNotMeetComplexity() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "password", "+27821234567");

assertFalse(login.checkPasswordComplexity());
}

@Test
public void testCellphoneCorrectlyFormatted() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "+27821234567");

assertTrue(login.checkCellPhoneNumber());
}

@Test
public void testCellphoneIncorrectlyFormatted() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "0821234567");

assertFalse(login.checkCellPhoneNumber());
}

@Test
public void testLoginSuccessful() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "+27821234567");

assertTrue(login.loginUser("ntw_1", "Test@123"));
}

@Test
public void testLoginFailed() {
Login login = new Login(
"Ntwelo", "Makaringe",
"ntw_1", "Test@123", "+27821234567");

assertFalse(login.loginUser("ntw_1", "wrongpassword"));
}
}